/** InfluxDB v2 URL */
const url = process.env['INFLUXDB_URL'] || 'http://localhost:8089'
/** InfluxDB authorization token */
const token = process.env['INFLUXDB_TOKEN'] || 'RV4nLo4CKZYfO84XYtUxXQjUm6BP3XqMxssBG6x5S_Dlmuzt86Bja1znF4LhhoTRhzkMCkREVEPlpPJ6d6Icsw=='
/** Organization within InfluxDB URL  */
const org = process.env['INFLUXDB_ORG'] || 'ocarina'
/**InfluxDB bucket used in examples  */
const bucket = 'nmea'
// ONLY onboarding example
/**InfluxDB user  */
const username = 'my-user'
/**InfluxDB password  */
const password = 'my-password'

module.exports = {
  url,
  token,
  org,
  bucket,
  username,
  password,
}
