# influxdb-client-javascript

The reference javascript client for InfluxDB 2.0. Both node and browser environments are supported.
See https://github.com/influxdata/influxdb-client-js to know more.

**Note: This library is for use with InfluxDB 2.x or 1.8+. For connecting to InfluxDB 1.x instances, see [node-influx](https://github.com/node-influx/node-influx).**
