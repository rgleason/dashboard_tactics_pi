export const CLIENT_LIB_VERSION = '1.6.0'
