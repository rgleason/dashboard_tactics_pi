# influxdb-client-apis

Contains client APIs for InfluxDB v2.0. See https://github.com/influxdata/influxdb-client-js to know more.
